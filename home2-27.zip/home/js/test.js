var c = 0;
function biger()
{
    var demo = document.getElementById("demo");
    var dw = 1;
    var dh = 1;
    var loop1 = 0;
    while(loop1 < 100)
    {
        demo.style.width = demo.style.width+dw+"px";
        demo.style.height = demo.style.height+dh+"px";
        loop1++;
    }
}
